<?php
  include('includes/header.php');
?>
<title>Homepage</title>
<main style="padding: 50px">

<strong>
  <h1 style="text-align:center;"> Welcome to <br> SHIRTS-4-U  </h1>

</strong>


</main>

<?php
include('includes/footer.php');
?>
