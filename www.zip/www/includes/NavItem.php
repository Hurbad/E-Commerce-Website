<?php

//Nav item functions

$navItems = array(

  array(
        "slug" => "product.php",
        "title" => "Product",

  )


);




 ?>
