<?php
  include('includes/NavItem.php');
 ?>

<!DOCTYPE html>
<html>
<meta charset="UTF-8">
<link rel="shortcut icon" type="image/png" href="images/favicon.PNG"/>
<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>

<head>
<link rel="stylesheet" type="text/css" href="css/homepage.css">
</head>

<body>
<ul>
<li><a href="homepage.php"class="circle2"><img src="images/home.png"style="width:px;height:25px;"></a></li>
<?php include('includes/nav.php'); ?>
</ul>
