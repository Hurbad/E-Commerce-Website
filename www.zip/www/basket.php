<?php
  include('includes/header.php');
?>

<title>Basket</title>
<main style="position: inherit;width:1470px; height: 850px; color:white;">



  <!-- Displays contents of basket -->
<center>  <h2>Basket</h2> </center>
  <div id="basketDiv">
<!--Content-->
  </div>



</main>
<script src="script/basket.js"></script>
<?php
include('includes/footer.php');
?>
